# Marketing site — Cursor

Recreation of the Cursor.com surface, built from `uploads/DESIGN.md` only (no codebase or Figma access). Pixel-honest at the spec level, not section-for-section.

### Files
- `index.html` — interactive composition: top nav, hero with IDE mockup, feature grid, AI-timeline showcase, pricing, CTA band, footer.
- `TopNav.jsx` — wordmark left, menu, sign in + ink download CTA.
- `Buttons.jsx` — `PrimaryButton`, `SecondaryButton`, `DownloadButton`, `TertiaryLink`.
- `HeroBand.jsx` — 72px display headline, body subhead, dual CTAs.
- `IdeMockupCard.jsx` — three-pane editor (sidebar / editor / agent), JetBrains Mono, agent timeline pills.
- `TimelinePill.jsx` — the 5 pastel pills (`thinking | grep | read | edit | done`).
- `FeatureCard.jsx` — hairline-bordered white card, 24px padding.
- `PricingTier.jsx` — standard + ink-inverted featured variants.
- `CtaBand.jsx` — 96px pre-footer band.
- `Footer.jsx` — 5-column link list, body-sm copy.

### Interactions wired
- Top-nav menu items hover-darken from `--body` to `--ink`.
- Primary CTA hover/press swap to `--primary-active`.
- Pricing tier card hover surfaces a 1px hairline-strong border.
- Agent-timeline pills enter sequentially when the IDE mockup scrolls into view.

### Substitutions
- **Inter** stands in for **CursorGothic** at -1.5% letter-spacing.
- Icons: none used in marketing surface (this matches the spec). The IDE mockup uses small inline SVG carets only.
