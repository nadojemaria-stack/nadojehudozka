/* global React */
function TopNav({ onSignIn, onDownload }) {
  const links = ["Pricing", "Features", "Enterprise", "Blog", "Forum", "Careers"];
  return (
    <nav style={{
      height: 64, background: "var(--canvas)", color: "var(--ink)",
      display: "flex", alignItems: "center", padding: "0 32px", gap: 32,
      borderBottom: "1px solid var(--hairline-soft)",
    }}>
      <div style={{
        fontFamily: "var(--font-display)", fontSize: 22, fontWeight: 400,
        letterSpacing: "-0.66px", color: "var(--primary)",
      }}>Cursor</div>
      <div style={{display:"flex", gap: 24, marginLeft: 8, flex: 1}}>
        {links.map(l => (
          <a key={l} style={{
            fontFamily: "var(--font-body)", fontSize: 14, fontWeight: 500,
            color: "var(--ink)", textDecoration: "none", cursor: "pointer",
          }}>{l}</a>
        ))}
      </div>
      <a onClick={onSignIn} style={{
        fontFamily: "var(--font-body)", fontSize: 14, fontWeight: 500,
        color: "var(--ink)", textDecoration: "none", cursor: "pointer",
      }}>Sign in</a>
      <DownloadButton onClick={onDownload}>Download</DownloadButton>
    </nav>
  );
}

Object.assign(window, { TopNav });
