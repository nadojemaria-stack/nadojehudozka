/* global React */
function PricingTier({ name, price, per, blurb, perks, featured, cta }) {
  const isDark = !!featured;
  const surface = isDark ? "var(--ink)" : "var(--surface-card)";
  const onSurface = isDark ? "var(--canvas)" : "var(--ink)";
  const muted = isDark ? "rgba(247,247,244,0.6)" : "var(--muted)";
  return (
    <div style={{
      background: surface, color: onSurface,
      border: isDark ? "1px solid var(--ink)" : "1px solid var(--hairline)",
      borderRadius: "var(--radius-lg)", padding: 32,
    }}>
      <div style={{
        fontSize: 11, fontWeight: 600, letterSpacing: "0.88px", textTransform: "uppercase",
        color: muted,
      }}>{name}</div>
      <div style={{display:"flex", alignItems:"baseline", gap: 8, marginTop: 16}}>
        <div style={{
          fontFamily: "var(--font-display)", fontSize: 48, fontWeight: 400,
          letterSpacing: "-1.44px", lineHeight: 1, color: onSurface,
        }}>{price}</div>
        <div style={{fontSize: 13, color: muted}}>{per}</div>
      </div>
      <div style={{
        fontSize: 14, color: isDark ? "rgba(247,247,244,0.85)" : "var(--body)",
        marginTop: 12, lineHeight: 1.5,
      }}>{blurb}</div>
      <ul style={{listStyle:"none", padding:0, margin:"24px 0 28px", display:"flex", flexDirection:"column", gap:8}}>
        {perks.map((p, i) => (
          <li key={i} style={{
            fontSize: 14, lineHeight: 1.5,
            color: isDark ? "var(--canvas)" : "var(--ink)",
            display:"flex", gap: 8,
          }}>
            <span aria-hidden style={{color: isDark ? "var(--timeline-grep)" : "var(--semantic-success)"}}>✓</span>
            <span>{p}</span>
          </li>
        ))}
      </ul>
      <button style={{
        width: "100%", height: 44, borderRadius: "var(--radius-md)", border: 0,
        background: isDark ? "var(--primary)" : "var(--ink)",
        color: isDark ? "var(--on-primary)" : "var(--canvas)",
        fontFamily: "var(--font-body)", fontSize: 14, fontWeight: 500, cursor: "pointer",
      }}>{cta}</button>
    </div>
  );
}

function PricingGrid() {
  return (
    <section style={{padding: "80px 32px", background: "var(--canvas)"}}>
      <div style={{maxWidth: 1100, margin: "0 auto"}}>
        <h2 style={{
          fontFamily: "var(--font-display)", fontSize: 36, fontWeight: 400,
          lineHeight: 1.2, letterSpacing: "-0.72px", color: "var(--ink)",
          margin: "0 0 40px", textAlign: "center",
        }}>Pricing.</h2>
        <div style={{display:"grid", gridTemplateColumns:"repeat(3, 1fr)", gap: 20}}>
          <PricingTier name="Hobby" price="Free" per="forever"
            blurb="Pro two-week trial. Limited completions and slow requests."
            perks={["50 slow requests / mo", "200 completions / mo", "Privacy mode"]}
            cta="Get started" />
          <PricingTier name="Pro" price="$20" per="per month" featured
            blurb="Unlimited completions. 500 fast requests. Frontier models."
            perks={["Unlimited completions", "500 fast requests / mo", "Unlimited slow requests", "Max-context window"]}
            cta="Upgrade" />
          <PricingTier name="Business" price="$40" per="per user / mo"
            blurb="Privacy mode by default. SAML SSO. Centralized billing."
            perks={["Everything in Pro", "Org-wide privacy mode", "SAML SSO", "Admin dashboard"]}
            cta="Contact sales" />
        </div>
      </div>
    </section>
  );
}

Object.assign(window, { PricingTier, PricingGrid });
