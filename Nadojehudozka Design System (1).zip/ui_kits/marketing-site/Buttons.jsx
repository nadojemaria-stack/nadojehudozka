/* global React */
const { useState } = React;

function PrimaryButton({ children, onClick, active }) {
  const [press, setPress] = useState(false);
  const bg = (press || active) ? "var(--primary-active)" : "var(--primary)";
  return (
    <button
      onClick={onClick}
      onMouseDown={() => setPress(true)}
      onMouseUp={() => setPress(false)}
      onMouseLeave={() => setPress(false)}
      style={{
        background: bg, color: "var(--on-primary)",
        fontFamily: "var(--font-body)", fontSize: 14, fontWeight: 500, lineHeight: 1,
        padding: "10px 18px", height: 40, borderRadius: "var(--radius-md)",
        border: 0, cursor: "pointer", transition: "background 120ms ease-out",
      }}
    >{children}</button>
  );
}

function SecondaryButton({ children, onClick }) {
  return (
    <button onClick={onClick} style={{
      background: "var(--surface-card)", color: "var(--ink)",
      fontFamily: "var(--font-body)", fontSize: 14, fontWeight: 500, lineHeight: 1,
      padding: "9px 17px", height: 40, borderRadius: "var(--radius-md)",
      border: "1px solid var(--hairline-strong)", cursor: "pointer",
    }}>{children}</button>
  );
}

function DownloadButton({ children = "Download for macOS", onClick }) {
  return (
    <button onClick={onClick} style={{
      background: "var(--ink)", color: "var(--canvas)",
      fontFamily: "var(--font-body)", fontSize: 14, fontWeight: 500, lineHeight: 1,
      padding: "12px 20px", height: 44, borderRadius: "var(--radius-md)",
      border: 0, cursor: "pointer",
    }}>{children}</button>
  );
}

function TertiaryLink({ children, onClick }) {
  return (
    <a onClick={onClick} style={{
      color: "var(--ink)", fontFamily: "var(--font-body)", fontSize: 14, fontWeight: 500,
      cursor: "pointer", textDecoration: "none", display: "inline-flex", alignItems: "center", gap: 6,
    }}>{children} <span aria-hidden style={{opacity:0.6}}>→</span></a>
  );
}

Object.assign(window, { PrimaryButton, SecondaryButton, DownloadButton, TertiaryLink });
