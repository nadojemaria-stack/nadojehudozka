/* global React, TimelinePill */
const { useEffect, useState } = React;

function IdeMockupCard() {
  const [step, setStep] = useState(0);
  useEffect(() => {
    const id = setInterval(() => setStep(s => (s + 1) % 6), 1400);
    return () => clearInterval(id);
  }, []);

  const files = [
    { p: "src/", indent: 0, dim: true },
    { p: "server/", indent: 1, dim: true },
    { p: "auth/session.ts", indent: 2, active: true },
    { p: "db/schema.ts", indent: 2 },
    { p: "routes/", indent: 1, dim: true },
    { p: "utils/", indent: 1, dim: true },
  ];

  const timeline = [
    { kind: "thinking", text: "plan three-step migration", dur: "2.4s" },
    { kind: "read",     text: "src/server/db/schema.ts",   dur: "0.6s" },
    { kind: "grep",     text: "\"createSession\" · 14 hits", dur: "0.3s" },
    { kind: "edit",     text: "src/server/auth/session.ts", dur: "1.1s" },
    { kind: "done",     text: "3 files changed · 41 / −12", dur: ""    },
  ];

  return (
    <div style={{
      background: "var(--surface-card)",
      border: "1px solid var(--hairline)",
      borderRadius: "var(--radius-lg)",
      overflow: "hidden",
      maxWidth: 1100, margin: "0 auto",
    }}>
      <div style={{
        display: "flex", alignItems: "center", gap: 6,
        padding: "12px 16px",
        borderBottom: "1px solid var(--hairline-soft)",
        background: "var(--canvas-soft)",
      }}>
        <span style={{width:10,height:10,borderRadius:9999,background:"var(--hairline-strong)"}}></span>
        <span style={{width:10,height:10,borderRadius:9999,background:"var(--hairline-strong)"}}></span>
        <span style={{width:10,height:10,borderRadius:9999,background:"var(--hairline-strong)"}}></span>
        <span style={{
          marginLeft: 14, fontFamily: "var(--font-mono)", fontSize: 12, color: "var(--muted)",
        }}>
          <span style={{color:"var(--ink)"}}>session.ts</span> &nbsp;·&nbsp; src/server/auth
        </span>
      </div>

      <div style={{display:"grid", gridTemplateColumns:"180px 1fr 280px", minHeight: 360}}>
        {/* sidebar */}
        <div style={{
          padding: "14px 12px", borderRight: "1px solid var(--hairline-soft)",
          fontFamily: "var(--font-mono)", fontSize: 12, color: "var(--body)",
        }}>
          {files.map((f, i) => (
            <div key={i} style={{
              padding: "4px 8px",
              paddingLeft: 8 + f.indent * 14,
              background: f.active ? "var(--surface-strong)" : "transparent",
              borderRadius: 4,
              color: f.active ? "var(--ink)" : (f.dim ? "var(--muted)" : "var(--body)"),
            }}>{f.p}</div>
          ))}
        </div>

        {/* editor */}
        <div style={{
          padding: 18, fontFamily: "var(--font-mono)", fontSize: 13, color: "var(--ink)",
          lineHeight: 1.7, background: "var(--surface-card)",
        }}>
          <div style={{color:"var(--muted)"}}>// rotate session keys</div>
          <div><span style={{color:"#cf2d56"}}>export async function</span> rotate(id: <span style={{color:"#cf2d56"}}>string</span>) {"{"}</div>
          <div>&nbsp;&nbsp;<span style={{color:"#cf2d56"}}>const</span> next = <span style={{color:"#cf2d56"}}>await</span> nextKey();</div>
          <div style={{background:"rgba(159,201,162,0.25)", padding:"0 4px", margin:"0 -4px", borderRadius:2}}>
            &nbsp;&nbsp;<span style={{color:"#cf2d56"}}>await</span> db.session.update({"{"} where: {"{"} id {"}"}, data: {"{"} key: next {"}"} {"}"});
          </div>
          <div>&nbsp;&nbsp;<span style={{color:"#cf2d56"}}>return</span> <span style={{color:"#1f8a65"}}>"rotated"</span></div>
          <div>{"}"}</div>
        </div>

        {/* agent panel */}
        <div style={{
          padding: 14, borderLeft: "1px solid var(--hairline-soft)",
          background: "var(--canvas-soft)", display:"flex", flexDirection:"column", gap: 12,
        }}>
          <div style={{
            fontSize: 11, fontWeight: 600, letterSpacing: "0.88px", textTransform: "uppercase",
            color: "var(--muted)",
          }}>Agent</div>
          {timeline.map((t, i) => (
            <div key={i} style={{
              display: "flex", flexDirection: "column", gap: 4,
              opacity: i <= step ? 1 : 0.25,
              transition: "opacity 280ms ease-out",
            }}>
              <TimelinePill kind={t.kind} />
              <div style={{
                fontFamily: "var(--font-mono)", fontSize: 11, color: "var(--body)", lineHeight: 1.4,
              }}>{t.text}{t.dur ? <span style={{color:"var(--muted)"}}> · {t.dur}</span> : null}</div>
            </div>
          ))}
        </div>
      </div>
    </div>
  );
}

Object.assign(window, { IdeMockupCard });
