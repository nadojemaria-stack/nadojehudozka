/* global React */
function FeatureCard({ eyebrow, title, body }) {
  return (
    <div style={{
      background: "var(--surface-card)",
      border: "1px solid var(--hairline)",
      borderRadius: "var(--radius-lg)",
      padding: 24,
    }}>
      {eyebrow ? (
        <div style={{
          fontSize: 11, fontWeight: 600, letterSpacing: "0.88px", textTransform: "uppercase",
          color: "var(--muted)", marginBottom: 12,
        }}>{eyebrow}</div>
      ) : null}
      <div style={{
        fontFamily: "var(--font-display)", fontSize: 22, fontWeight: 400,
        letterSpacing: "-0.11px", color: "var(--ink)", lineHeight: 1.3,
        marginBottom: 8,
      }}>{title}</div>
      <div style={{
        fontFamily: "var(--font-body)", fontSize: 14, fontWeight: 400,
        lineHeight: 1.5, color: "var(--body)",
      }}>{body}</div>
    </div>
  );
}

function FeatureGrid() {
  const features = [
    { eyebrow: "Tab", title: "Tab completes anything.",
      body: "The default model can complete edits across multiple lines, taking into account your recent changes." },
    { eyebrow: "Codebase", title: "Knows your codebase.",
      body: "Get answers from anywhere in your repo, or reference a specific file or symbol." },
    { eyebrow: "Agent", title: "Multi-file edits.",
      body: "Apply coherent changes across many files in one pass — review, accept, or reject per hunk." },
    { eyebrow: "Apply", title: "Code runs at the speed of thought.",
      body: "Cursor's fast apply turns suggestions into edits without leaving the editor." },
    { eyebrow: "Privacy", title: "Privacy mode.",
      body: "Your code is never trained on, never stored remotely. SOC 2 certified." },
    { eyebrow: "Familiar", title: "VS Code, but better.",
      body: "Bring your extensions, themes, and keybindings. Cursor is a fork of VS Code." },
  ];
  return (
    <section style={{padding: "80px 32px", background: "var(--canvas)"}}>
      <div style={{maxWidth: 1200, margin: "0 auto"}}>
        <h2 style={{
          fontFamily: "var(--font-display)", fontSize: 36, fontWeight: 400,
          lineHeight: 1.2, letterSpacing: "-0.72px", color: "var(--ink)",
          margin: "0 0 40px", maxWidth: 720,
        }}>Built to make you extraordinarily productive.</h2>
        <div style={{
          display: "grid", gridTemplateColumns: "repeat(3, 1fr)", gap: 20,
        }}>
          {features.map((f, i) => <FeatureCard key={i} {...f} />)}
        </div>
      </div>
    </section>
  );
}

Object.assign(window, { FeatureCard, FeatureGrid });
