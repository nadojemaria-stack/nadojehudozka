/* global React, PrimaryButton */
function CtaBand() {
  return (
    <section style={{padding: "96px 32px", background: "var(--canvas)", textAlign: "center"}}>
      <h2 style={{
        fontFamily: "var(--font-display)", fontSize: 36, fontWeight: 400,
        lineHeight: 1.2, letterSpacing: "-0.72px", color: "var(--ink)",
        margin: "0 0 24px",
      }}>Try Cursor now.</h2>
      <PrimaryButton>Download for macOS</PrimaryButton>
    </section>
  );
}

function Footer() {
  const cols = [
    { h: "Product", links: ["Pricing", "Features", "Enterprise", "Downloads", "Students"] },
    { h: "Resources", links: ["Docs", "Forum", "Changelog", "Privacy", "Security"] },
    { h: "Company", links: ["Anysphere", "Careers", "Blog", "Community", "Customers"] },
    { h: "Legal", links: ["Terms of service", "Privacy policy", "Acceptable use"] },
  ];
  return (
    <footer style={{
      background: "var(--canvas)", color: "var(--body)",
      padding: "64px 48px", borderTop: "1px solid var(--hairline-soft)",
    }}>
      <div style={{maxWidth: 1200, margin: "0 auto", display: "grid", gridTemplateColumns: "1.4fr repeat(4, 1fr)", gap: 32}}>
        <div>
          <div style={{
            fontFamily: "var(--font-display)", fontSize: 26, fontWeight: 400,
            letterSpacing: "-0.78px", color: "var(--primary)",
          }}>Cursor</div>
          <div style={{fontSize: 13, color: "var(--muted)", marginTop: 12}}>Made by Anysphere</div>
        </div>
        {cols.map(c => (
          <div key={c.h}>
            <div style={{
              fontSize: 11, fontWeight: 600, letterSpacing: "0.88px", textTransform: "uppercase",
              color: "var(--muted)", marginBottom: 14,
            }}>{c.h}</div>
            <ul style={{listStyle:"none", padding:0, margin:0, display:"flex", flexDirection:"column", gap: 10}}>
              {c.links.map(l => (
                <li key={l}>
                  <a style={{
                    fontSize: 14, color: "var(--body)", textDecoration: "none", cursor: "pointer",
                  }}>{l}</a>
                </li>
              ))}
            </ul>
          </div>
        ))}
      </div>
      <div style={{
        maxWidth: 1200, margin: "48px auto 0", paddingTop: 24,
        borderTop: "1px solid var(--hairline-soft)",
        display: "flex", justifyContent: "space-between", color: "var(--muted)", fontSize: 12,
      }}>
        <div>© Anysphere · All rights reserved.</div>
        <div>Made with love in San Francisco.</div>
      </div>
    </footer>
  );
}

Object.assign(window, { CtaBand, Footer });
