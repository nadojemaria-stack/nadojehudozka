/* global React, TimelinePill */
function TimelineShowcase() {
  const rows = [
    { kind: "thinking", text: "plan three-step migration",        dur: "2.4s" },
    { kind: "read",     text: "src/server/db/schema.ts",          dur: "0.6s" },
    { kind: "grep",     text: "\"createSession\" · 14 hits",      dur: "0.3s" },
    { kind: "edit",     text: "src/server/auth/session.ts",       dur: "1.1s" },
    { kind: "done",     text: "3 files changed · 41 / −12",       dur: ""    },
  ];
  return (
    <section style={{padding: "80px 32px", background: "var(--canvas)"}}>
      <div style={{maxWidth: 1200, margin: "0 auto", display:"grid", gridTemplateColumns: "1fr 1.2fr", gap: 64, alignItems: "center"}}>
        <div>
          <div style={{
            fontSize: 11, fontWeight: 600, letterSpacing: "0.88px", textTransform: "uppercase",
            color: "var(--muted)", marginBottom: 16,
          }}>Agent timeline</div>
          <h2 style={{
            fontFamily: "var(--font-display)", fontSize: 36, fontWeight: 400,
            lineHeight: 1.2, letterSpacing: "-0.72px", color: "var(--ink)",
            margin: "0 0 16px",
          }}>You can see what the agent is doing.</h2>
          <p style={{
            fontFamily: "var(--font-body)", fontSize: 16, fontWeight: 400,
            lineHeight: 1.5, color: "var(--body)", margin: 0, maxWidth: 460,
          }}>Each stage — thinking, reading, grepping, editing, done — gets its own pill. Color is the affordance; the pill <em>is</em> the icon.</p>
        </div>
        <div style={{
          background: "var(--surface-card)", border: "1px solid var(--hairline)",
          borderRadius: "var(--radius-lg)", padding: 18,
        }}>
          {rows.map((r, i) => (
            <div key={i} style={{
              display:"flex", alignItems:"center", gap: 14, padding: "10px 4px",
              borderBottom: i < rows.length - 1 ? "1px solid var(--hairline-soft)" : "0",
              fontFamily: "var(--font-mono)", fontSize: 12, color: "var(--body)",
            }}>
              <div style={{minWidth: 90}}><TimelinePill kind={r.kind} /></div>
              <span style={{color:"var(--ink)", flex: 1}}>{r.text}</span>
              <span style={{color:"var(--muted)"}}>{r.dur}</span>
            </div>
          ))}
        </div>
      </div>
    </section>
  );
}

Object.assign(window, { TimelineShowcase });
