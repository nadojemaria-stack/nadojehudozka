/* global React, DownloadButton, TertiaryLink, IdeMockupCard */
function HeroBand() {
  return (
    <section style={{
      background: "var(--canvas)", padding: "80px 32px 80px",
    }}>
      <div style={{maxWidth: 1100, margin: "0 auto", textAlign: "center"}}>
        <h1 style={{
          fontFamily: "var(--font-display)", fontSize: 72, fontWeight: 400,
          lineHeight: 1.1, letterSpacing: "-2.16px", color: "var(--ink)",
          margin: 0, textWrap: "pretty",
        }}>The AI code editor</h1>
        <p style={{
          fontFamily: "var(--font-body)", fontSize: 18, fontWeight: 400,
          lineHeight: 1.5, color: "var(--body)", margin: "20px auto 0",
          maxWidth: 620,
        }}>
          Built to make you extraordinarily productive, Cursor is the best way
          to code with AI.
        </p>
        <div style={{
          display: "flex", gap: 16, justifyContent: "center",
          marginTop: 32, alignItems: "center", flexWrap: "wrap",
        }}>
          <DownloadButton>Download for macOS</DownloadButton>
          <TertiaryLink>All downloads</TertiaryLink>
        </div>
      </div>

      <div style={{marginTop: 64, padding: "0 32px"}}>
        <IdeMockupCard />
      </div>
    </section>
  );
}

Object.assign(window, { HeroBand });
