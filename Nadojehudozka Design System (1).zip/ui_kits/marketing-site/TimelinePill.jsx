/* global React */
const TIMELINE_TOKENS = {
  thinking: { bg: "var(--timeline-thinking)", fg: "var(--ink)", label: "Thinking" },
  grep:     { bg: "var(--timeline-grep)",     fg: "var(--ink)", label: "Grepping" },
  read:     { bg: "var(--timeline-read)",     fg: "var(--ink)", label: "Reading"  },
  edit:     { bg: "var(--timeline-edit)",     fg: "var(--ink)", label: "Editing"  },
  done:     { bg: "var(--timeline-done)",     fg: "#ffffff",    label: "Done"     },
};

function TimelinePill({ kind = "thinking", children }) {
  const t = TIMELINE_TOKENS[kind];
  return (
    <span style={{
      background: t.bg, color: t.fg,
      fontFamily: "var(--font-body)", fontSize: 11, fontWeight: 600,
      letterSpacing: "0.88px", textTransform: "uppercase", lineHeight: 1.4,
      padding: "4px 10px", borderRadius: "var(--radius-pill)",
      display: "inline-block", whiteSpace: "nowrap",
    }}>{children ?? t.label}</span>
  );
}

Object.assign(window, { TimelinePill, TIMELINE_TOKENS });
