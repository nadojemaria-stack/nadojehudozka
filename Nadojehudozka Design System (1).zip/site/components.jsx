/* Reusable components: Nav, Footer, Tile, AvatarRow, MoodChip, etc.
   Exposes everything to window for the page scripts. */

const { useState, useEffect, useRef, useCallback } = React;

/* ---------- Tile: crops one cell from cover.jpg ---------- */
function Tile({ cell, shape = 'square', className = '', style }) {
  return (
    <div
      className={`tile tile--${shape} ${className}`}
      data-cell={cell}
      style={style}
      aria-hidden="true"
    />
  );
}

/* ---------- Nav ---------- */
function TopNav({ route, navigate, theme, onToggleTheme, courseUnlocked }) {
  const links = [
    { id: 'hub',        label: 'Курсы',         to: { name: 'hub' } },
    { id: 'sketching',  label: 'Скетчинг',      to: { name: 'aggregator', course: 'sketching' }, hideMobile: false },
    { id: 'library',    label: 'Библиотека',    to: { name: 'hub' }, external: true, hideMobile: true },
  ];

  return (
    <header className="topnav">
      <div className="shell shell--wide topnav__inner">
        <button className="brand-mark" onClick={() => navigate({ name: 'hub' })}>
          <span className="brand-mark__hash">#</span>надожехудожка
        </button>

        <nav className="topnav__links">
          {links.map(l => (
            <button
              key={l.id}
              className={`nav-link ${l.hideMobile ? 'hide-mobile' : ''} ${
                ((l.id === 'hub' && route.name === 'hub')
                 || (l.id === 'sketching' && (route.name === 'aggregator' || route.name === 'level' || route.name === 'task' || route.name === 'after')))
                  ? 'is-active' : ''
              }`}
              onClick={() => navigate(l.to)}
            >
              {l.label}
            </button>
          ))}
          <button
            className="theme-toggle"
            onClick={onToggleTheme}
            aria-label={theme === 'dark' ? 'Светлая тема' : 'Тёмная тема'}
            title={theme === 'dark' ? 'Светлая тема' : 'Тёмная тема'}
          >
            {theme === 'dark' ? (
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round"><circle cx="12" cy="12" r="4"/><path d="M12 2v2M12 20v2M2 12h2M20 12h2M4.93 4.93l1.41 1.41M17.66 17.66l1.41 1.41M4.93 19.07l1.41-1.41M17.66 6.34l1.41-1.41"/></svg>
            ) : (
              <svg width="16" height="16" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="1.6" strokeLinecap="round" strokeLinejoin="round"><path d="M21 12.79A9 9 0 1 1 11.21 3 7 7 0 0 0 21 12.79z"/></svg>
            )}
          </button>
        </nav>
      </div>
    </header>
  );
}

/* ---------- Footer ---------- */
function Footer({ navigate }) {
  return (
    <footer className="footer">
      <div className="shell shell--wide">
        <div className="footer__cols">
          <div className="footer__col" style={{ maxWidth: 280 }}>
            <h4>#надожехудожка</h4>
            <p style={{ margin: 0, lineHeight: 1.55 }}>
              Курсы и интенсивы Марии Щедриной. Для взрослых рисующих людей. Телефон в кармане, блокнот в руке.
            </p>
          </div>
          <div className="footer__col">
            <h4>Скетчинг</h4>
            <ul>
              <li><a onClick={() => navigate({ name: 'aggregator', course: 'sketching' })} style={{ cursor: 'pointer' }}>Уровень 1 — Рисуй где угодно</a></li>
              <li><a>Уровень 2 — Смотри как художник</a></li>
              <li><a>Уровень 3 — Свой почерк</a></li>
            </ul>
          </div>
          <div className="footer__col">
            <h4>Интенсивы</h4>
            <ul>
              <li><a>Движуха на плоскости</a></li>
              <li><a>Иллюзия пространства</a></li>
            </ul>
          </div>
          <div className="footer__col">
            <h4>Связь</h4>
            <ul>
              <li><a href="https://artistshedrina.ru" target="_blank" rel="noreferrer">artistshedrina.ru</a></li>
              <li><a>Телеграм</a></li>
              <li><a>hello@artistshedrina.ru</a></li>
            </ul>
          </div>
        </div>
        <div className="legal">
          <span>© 2025 Мария Щедрина</span>
          <span>версия β · прототип</span>
        </div>
      </div>
    </footer>
  );
}

/* ---------- AvatarRow: 3 cards desktop / carousel mobile ---------- */
function AvatarRow({ quotes }) {
  // quotes is { olga: '...', maria: '...', uu: '...' }
  const order = ['olga', 'maria', 'uu'];
  const wrapRef = useRef(null);
  const [active, setActive] = useState(0);

  useEffect(() => {
    const wrap = wrapRef.current;
    if (!wrap) return;
    const onScroll = () => {
      const w = wrap.clientWidth * 0.88;
      const idx = Math.round(wrap.scrollLeft / w);
      setActive(Math.max(0, Math.min(2, idx)));
    };
    wrap.addEventListener('scroll', onScroll, { passive: true });
    return () => wrap.removeEventListener('scroll', onScroll);
  }, []);

  return (
    <div>
      <div className="avatars" ref={wrapRef}>
        {order.map((id) => {
          const a = AVATARS[id];
          return (
            <article key={id} className="avatar-card" style={{ '--avatar-accent': a.accent }}>
              <div className="avatar-card__head">
                <div className="avatar-card__art" style={{ background: a.accent === '#1a1814' ? '#f6f1e6' : 'var(--canvas-soft)' }}>
                  <img src={a.img} alt={a.name} style={{ width: '100%', height: '100%', objectFit: 'contain', padding: 4 }} />
                </div>
                <div>
                  <div className="avatar-card__name">{a.name}</div>
                  <div className="avatar-card__role">{a.role}</div>
                </div>
              </div>
              <p className="avatar-card__quote">{quotes[id]}</p>
            </article>
          );
        })}
      </div>
      <div className="avatars-dots">
        {order.map((_, i) => <span key={i} className={i === active ? 'is-active' : ''} />)}
      </div>
    </div>
  );
}

/* ---------- StatusPill ---------- */
function StatusPill({ kind, children }) {
  return <span className={`pill pill--${kind}`}>{children}</span>;
}

/* ---------- Tag ---------- */
function Tag({ children }) {
  return <span className="tag">{children}</span>;
}

/* ---------- Price ---------- */
function Price({ value, old, currency = '₽' }) {
  return (
    <span className="price">
      {old ? <span className="price__strike">{old.toLocaleString('ru-RU')} {currency}</span> : null}
      {value.toLocaleString('ru-RU')}<span className="price__currency">{currency}</span>
    </span>
  );
}

/* ---------- Format helpers ---------- */
function todayLabel() {
  const d = new Date();
  const m = ['янв','фев','мар','апр','мая','июн','июл','авг','сен','окт','ноя','дек'];
  return `${String(d.getDate()).padStart(2,'0')} ${m[d.getMonth()]}`;
}

Object.assign(window, { Tile, TopNav, Footer, AvatarRow, StatusPill, Tag, Price, todayLabel });
